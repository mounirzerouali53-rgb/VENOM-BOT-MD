/**

 * Antilink Command

 */

const database = require('../../database');

module.exports = {

  name: 'منع_روابط',

  aliases: [],

  category: 'admin',

  description: 'حماية من الروابط',

  usage: '.منع_روابط <تشغيل/ايقاف/تعيين/عرض>',

  groupOnly: true,

  adminOnly: true,

  botAdminNeeded: true,

  

  async execute(sock, msg, args, extra) {

    try {

      if (!args[0]) {

        const settings = database.getGroupSettings(extra.from);

        const status = settings.antilink ? 'مفعل' : 'معطل';

        const action = settings.antilinkAction === 'kick' ? 'طرد' : 'حذف';

        return extra.reply(

          `🔗 *حالة منع الروابط*\n\n` +

          `الحالة: *${status}*\n` +

          `الإجراء: *${action}*\n\n` +

          `📖 *طريقة الاستعمال:*\n` +

          `  .منع_روابط تشغيل\n` +

          `  .منع_روابط ايقاف\n` +

          `  .منع_روابط تعيين حذف\n` +

          `  .منع_روابط تعيين طرد\n` +

          `  .منع_روابط عرض`

        );

      }

      

      const opt = args[0].toLowerCase();

      

      if (opt === 'تشغيل') {

        if (database.getGroupSettings(extra.from).antilink) {

          return extra.reply('*⚠️ منع الروابط مفعل بالفعل*');

        }

        database.updateGroupSettings(extra.from, { antilink: true });

        return extra.reply('*✅ تم تفعيل منع الروابط*');

      }

      

      if (opt === 'ايقاف') {

        database.updateGroupSettings(extra.from, { antilink: false });

        return extra.reply('*❌ تم تعطيل منع الروابط*');

      }

      

      if (opt === 'تعيين') {

        if (args.length < 2) {

          return extra.reply('*⚠️ اختر حذف او طرد*\nمثال: .منع_روابط تعيين حذف');

        }

        

        let setAction = args[1].toLowerCase();

        

        if (setAction === 'حذف') setAction = 'delete';

        else if (setAction === 'طرد') setAction = 'kick';

        else return extra.reply('*❌ خيار غير صالح اختر حذف او طرد*');

        

        database.updateGroupSettings(extra.from, { 

          antilinkAction: setAction,

          antilink: true

        });

        

        return extra.reply(`*✅ تم تعيين الاجراء الى ${args[1]}*`);

      }

      

      if (opt === 'عرض') {

        const settings = database.getGroupSettings(extra.from);

        const status = settings.antilink ? 'مفعل' : 'معطل';

        const action = settings.antilinkAction === 'kick' ? 'طرد' : 'حذف';

        return extra.reply(

          `📊 *اعدادات منع الروابط*\n\n` +

          `الحالة: *${status}*\n` +

          `الاجراء: *${action}*`

        );

      }

      

      return extra.reply('*📖 استعمل .منع_روابط لعرض الاعدادات*');

      

    } catch (error) {

      await extra.reply(`❌ خطأ: ${error.message}`);

    }

  }

};