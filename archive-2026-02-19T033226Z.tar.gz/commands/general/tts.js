/**

 * أمر تحويل النص إلى صوت - TTS

 */

const APIs = require('../../utils/api');

module.exports = {

  name: 'تحدث',

  aliases: ['تكلم', 'قول'],

  category: 'general',

  description: 'تحويل النص إلى رسالة صوتية',

  usage: '.تحدث <النص>',

  

  async execute(sock, msg, args, extra) {

    try {

      const chatId = extra.from;

      const text = args.join(' ');

      if (!text) {

        return extra.reply('❌ *الرجاء إدخال نص لتحويله إلى صوت.*\n*مثال:* .تحدث مرحبا كيف حالك');

      }

      const audioUrl = await APIs.textToSpeech(text);

      // تحميل الصوت كـ buffer

      const axios = require('axios');

      const audioResponse = await axios.get(audioUrl, {

        responseType: 'arraybuffer',

        timeout: 30000

      });

      

      const audioBuffer = Buffer.from(audioResponse.data);

      await sock.sendMessage(chatId, {

        audio: audioBuffer,

        mimetype: 'audio/mp3',

        ptt: true // تشغيله كملاحظة صوتية

      }, { quoted: msg });

    } catch (error) {

      console.error('TTS command error:', error);

      await extra.reply(`❌ *فشل إنشاء الرسالة الصوتية!*\n*الخطأ:* ${error.message}`);

    }

  }

};